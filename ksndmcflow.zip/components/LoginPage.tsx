
import React, { useState } from 'react';
import { User, Language } from '../types.ts';
import { ShieldCheck, User as UserIcon, AlertCircle, ArrowRight, Activity, Sparkles, Languages } from 'lucide-react';
import { translations } from '../services/translationService.ts';

interface Props {
  users: User[];
  onLogin: (userId: string) => void;
  language: Language;
  onLanguageToggle: () => void;
}

const LoginPage: React.FC<Props> = ({ users, onLogin, language, onLanguageToggle }) => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  const t = translations[language];

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    setError('');

    setTimeout(() => {
      const user = users.find(u => u.email.toLowerCase() === email.toLowerCase());
      if (user && user.password === password) {
        onLogin(user.id);
      } else {
        setError(language === 'EN' ? 'Invalid credentials. Access denied.' : 'ತಪ್ಪಾದ ರುಜುವಾತುಗಳು. ಪ್ರವೇಶ ನಿರಾಕರಿಸಲಾಗಿದೆ.');
        setIsLoading(false);
      }
    }, 1200);
  };

  return (
    <div className="min-h-screen w-full flex items-center justify-center p-4 sm:p-6 lg:p-12 bg-slate-50 relative overflow-hidden font-sans">
      {/* Dynamic Background Elements */}
      <div className="absolute top-[-20%] left-[-10%] w-[60%] h-[60%] bg-indigo-100/30 rounded-full blur-[160px] -z-10 animate-pulse"></div>
      <div className="absolute bottom-[-20%] right-[-10%] w-[60%] h-[60%] bg-brand-100/30 rounded-full blur-[160px] -z-10"></div>

      <div className="max-w-6xl w-full flex flex-col lg:flex-row bg-white rounded-[40px] lg:rounded-[60px] shadow-[0_32px_128px_-32px_rgba(0,0,0,0.12)] overflow-hidden border border-slate-100 relative z-10 min-h-[600px] lg:min-h-[800px]">
        
        {/* Branding Side - Hidden on small screens, shown on large */}
        <div className="hidden lg:flex lg:w-[45%] bg-[#0F172A] p-16 xl:p-24 flex-col justify-between text-white relative overflow-hidden">
          {/* Layered Gradients for Depth */}
          <div className="absolute top-0 right-0 w-full h-full opacity-40 bg-[radial-gradient(circle_at_top_right,_var(--tw-gradient-stops))] from-indigo-500 via-transparent to-transparent"></div>
          <div className="absolute bottom-0 left-0 w-full h-full opacity-20 bg-[radial-gradient(circle_at_bottom_left,_var(--tw-gradient-stops))] from-brand-500 via-transparent to-transparent"></div>
          
          <div className="relative z-10">
            <div className="flex items-center space-x-4 mb-20">
              <div className="bg-indigo-600 p-3.5 rounded-2xl shadow-xl shadow-indigo-600/30 ring-4 ring-indigo-600/10">
                <Activity className="text-white" size={32} />
              </div>
              <span className="text-3xl font-black tracking-tighter bg-clip-text text-transparent bg-gradient-to-r from-white to-slate-400">
                {t.systemName}
              </span>
            </div>
            
            <div className="space-y-8">
              <h1 className="text-6xl xl:text-7xl font-black leading-tight tracking-tighter">
                Workforce<br/>
                <span className="bg-clip-text text-transparent bg-gradient-to-r from-indigo-400 to-indigo-100">
                  Refined.
                </span>
              </h1>
              <p className="text-slate-400 text-lg xl:text-xl font-medium leading-relaxed max-w-sm">
                Intelligent governance for Ksndmc. Precision tracking and human-centric management.
              </p>
            </div>
          </div>

          <div className="relative z-10 flex items-center space-x-3 opacity-60">
            <div className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></div>
            <span className="text-[10px] font-black uppercase tracking-[0.5em] text-slate-400">System v2.0 Ready</span>
          </div>
        </div>

        {/* Form Side */}
        <div className="w-full lg:w-[55%] flex flex-col bg-white relative">
          
          {/* Language Selector Top-Right */}
          <div className="absolute top-8 right-8 lg:top-12 lg:right-12 z-20">
            <button 
              onClick={onLanguageToggle} 
              className="flex items-center space-x-2 px-4 py-2 bg-slate-50 border border-slate-100 rounded-xl text-[10px] font-black text-slate-600 hover:bg-white hover:shadow-lg transition-all uppercase tracking-widest active:scale-95"
            >
              <Languages size={14} className="text-indigo-600" />
              <span>{language === 'EN' ? 'KN' : 'EN'}</span>
            </button>
          </div>

          <div className="flex-1 flex flex-col justify-center items-center p-8 md:p-16 lg:p-24">
            <div className="max-w-md w-full">
              {/* Form Header */}
              <div className="mb-12">
                <div className="inline-flex items-center space-x-2 px-3 py-1 bg-indigo-50 text-indigo-600 rounded-full text-[9px] font-black uppercase tracking-widest mb-6 border border-indigo-100/50">
                  <Sparkles size={12} className="animate-pulse" />
                  <span>Secure Governance Portal</span>
                </div>
                <h2 className="text-4xl lg:text-5xl font-black text-slate-900 mb-4 tracking-tighter">
                  {t.systemGateway}
                </h2>
                <p className="text-slate-400 font-bold text-lg">{t.identityVerification}</p>
              </div>

              {/* Login Form */}
              <form onSubmit={handleSubmit} className="space-y-6">
                <div className="space-y-2">
                  <label className="text-[10px] font-black text-slate-500 ml-1 uppercase tracking-[0.2em]">
                    {t.identityLabel}
                  </label>
                  <div className="relative group">
                    <UserIcon size={20} className="absolute left-6 top-1/2 -translate-y-1/2 text-slate-300 group-focus-within:text-indigo-600 transition-colors" />
                    <input 
                      type="email" 
                      required 
                      value={email} 
                      onChange={(e) => setEmail(e.target.value)} 
                      placeholder="name@ksndmcflow.com" 
                      className="w-full pl-14 pr-6 py-4 lg:py-5 bg-slate-50 border border-slate-100 rounded-[20px] lg:rounded-[24px] text-base font-bold focus:ring-4 focus:ring-indigo-600/5 focus:border-indigo-600 focus:bg-white outline-none transition-all placeholder:text-slate-300 shadow-sm" 
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <div className="flex justify-between items-center ml-1">
                    <label className="text-[10px] font-black text-slate-500 uppercase tracking-[0.2em]">
                      {t.accessKey}
                    </label>
                    <button type="button" className="text-[10px] font-black text-indigo-600 hover:text-indigo-800 transition-colors uppercase tracking-[0.1em]">
                      {t.resetSecret}
                    </button>
                  </div>
                  <div className="relative group">
                    <ShieldCheck size={20} className="absolute left-6 top-1/2 -translate-y-1/2 text-slate-300 group-focus-within:text-indigo-600 transition-colors" />
                    <input 
                      type="password" 
                      required 
                      value={password} 
                      onChange={(e) => setPassword(e.target.value)} 
                      placeholder="••••••••" 
                      className="w-full pl-14 pr-6 py-4 lg:py-5 bg-slate-50 border border-slate-100 rounded-[20px] lg:rounded-[24px] text-base font-bold focus:ring-4 focus:ring-indigo-600/5 focus:border-indigo-600 focus:bg-white outline-none transition-all shadow-sm" 
                    />
                  </div>
                </div>

                {error && (
                  <div className="flex items-center space-x-4 p-4 lg:p-5 bg-rose-50 text-rose-600 border border-rose-100 rounded-2xl lg:rounded-[24px] text-sm font-bold animate-in fade-in slide-in-from-top-4">
                    <AlertCircle size={20} className="flex-shrink-0" />
                    <span>{error}</span>
                  </div>
                )}

                <button 
                  type="submit" 
                  disabled={isLoading} 
                  className="w-full bg-[#0F172A] hover:bg-slate-800 text-white font-black py-5 lg:py-6 rounded-[20px] lg:rounded-[24px] shadow-2xl flex items-center justify-center space-x-4 transition-all transform hover:-translate-y-1 active:translate-y-0 disabled:opacity-50 group overflow-hidden relative mt-4"
                >
                  <div className="absolute inset-0 bg-gradient-to-r from-indigo-600 to-indigo-500 opacity-0 group-hover:opacity-100 transition-opacity"></div>
                  {isLoading ? (
                    <div className="w-6 h-6 border-4 border-white/20 border-t-white rounded-full animate-spin relative z-10"></div>
                  ) : (
                    <div className="flex items-center space-x-3 relative z-10">
                      <span className="text-xl tracking-tighter uppercase">{t.authenticate}</span>
                      <ArrowRight size={22} className="group-hover:translate-x-2 transition-transform" />
                    </div>
                  )}
                </button>
              </form>

              <div className="mt-16 pt-8 border-t border-slate-50 text-center lg:text-left">
                <p className="text-slate-400 text-[10px] font-bold uppercase tracking-[0.25em]">
                  Secure Enterprise Node &copy; 2026 Ksndmc
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default LoginPage;
