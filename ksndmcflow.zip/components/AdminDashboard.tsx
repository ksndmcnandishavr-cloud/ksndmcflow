
import React, { useState, useMemo } from 'react';
import { AppState, Attendance, AttendanceStatus, User, LeaveBalance, EmployeeType, LeaveRequest } from '../types.ts';
import { ATTENDANCE_LABELS, STATUS_COLORS, GOK_HOLIDAYS_2026, getSpecialDayInfo } from '../constants.ts';
import { exportToExcel, exportToPDF } from '../services/exportService.ts';
import { 
  Calendar as CalendarIcon, 
  UserPlus, 
  Users, 
  Clock, 
  Zap, 
  SearchIcon, 
  Download, 
  Check, 
  Info, 
  X, 
  Pencil,
  Trash2,
  CheckSquare,
  Square,
  FileSpreadsheet,
  FileText,
  Filter,
  MoreVertical,
  CheckCircle2,
  XCircle,
  Timer,
  Edit3,
  ChevronRight,
  ChevronDown,
  ShieldCheck
} from 'lucide-react';
import { translations } from '../services/translationService.ts';

interface StatCardProps {
  title: string;
  value: string | number;
  icon: React.ReactNode;
  color: string;
  trend?: string;
  subValue?: string;
  urgent?: boolean;
}

const StatCard: React.FC<StatCardProps> = ({ title, value, icon, color, trend, subValue, urgent }) => (
  <div className="p-6 bg-white rounded-3xl border border-slate-100 shadow-sm relative overflow-hidden group transition-all hover:shadow-md hover:border-brand-100">
    <div className="relative z-10">
      <div className="flex items-center justify-between mb-4">
        <div className={`w-14 h-14 ${color} rounded-2xl flex items-center justify-center transition-transform group-hover:scale-110`}>
          {icon}
        </div>
        {trend && (
          <span className={`text-[10px] font-black px-2.5 py-1 rounded-lg ${urgent ? 'bg-rose-500 text-white' : 'bg-slate-100 text-slate-500'}`}>
            {trend}
          </span>
        )}
      </div>
      <div>
        <h4 className="text-xs font-bold text-slate-400 uppercase tracking-widest mb-1">{title}</h4>
        <p className="text-4xl font-black text-slate-900 tracking-tighter">
          {value}
        </p>
      </div>
      {subValue && (
        <p className="text-[10px] font-bold text-slate-300 uppercase tracking-widest mt-4 flex items-center">
          <span className="w-2 h-2 rounded-full bg-brand-500 mr-2"></span>
          {subValue}
        </p>
      )}
    </div>
  </div>
);

interface Props {
  state: AppState;
  updateAttendance: (records: Attendance[]) => void;
  updateLeaveStatus: (id: string, status: 'APPROVED' | 'REJECTED') => void;
  addUser: (user: User, initialBalance?: Partial<LeaveBalance>) => void;
  updateUser: (userId: string, updates: Partial<User>, balanceUpdates: Partial<LeaveBalance>) => void;
  deleteUser: (userId: string) => void;
  updateBalance: (userId: string, balance: Partial<LeaveBalance>) => void;
}

const AdminDashboard: React.FC<Props> = ({ state, updateAttendance, updateLeaveStatus, addUser, updateUser, deleteUser, updateBalance }) => {
  const [selectedDate, setSelectedDate] = useState(new Date('2026-01-01').toISOString().split('T')[0]);
  const [activeTab, setActiveTab] = useState<'attendance' | 'leaves' | 'employees' | 'holidays' | 'analytics'>('attendance');
  const [showAddUserModal, setShowAddUserModal] = useState(false);
  const [showManualPunchModal, setShowManualPunchModal] = useState(false);
  const [editingUser, setEditingUser] = useState<User | null>(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedUserIds, setSelectedUserIds] = useState<Set<string>>(new Set());
  const [showAttExportMenu, setShowAttExportMenu] = useState(false);
  const [showStaffExportMenu, setShowStaffExportMenu] = useState(false);

  const [manualPunchData, setManualPunchData] = useState({
    userId: '',
    date: new Date('2026-01-01').toISOString().split('T')[0],
    status: 'PRESENT' as AttendanceStatus,
    checkIn: '10:30',
    checkOut: '17:30'
  });

  const t = translations[state.language];
  const pendingLeaves = state.leaveRequests.filter(r => r.status === 'PENDING');
  
  const getAttendanceForUser = (userId: string, date: string) => {
    return state.attendance.find(a => a.userId === userId && a.date === date);
  };

  const handleAttendanceChange = (userId: string, status: AttendanceStatus, checkIn?: string, checkOut?: string) => {
    const existing = getAttendanceForUser(userId, selectedDate);
    const record: Attendance = {
      id: existing?.id || Math.random().toString(36).substr(2, 9),
      userId,
      date: selectedDate,
      status: status,
      checkIn: checkIn || existing?.checkIn || '10:30',
      checkOut: checkOut || existing?.checkOut || '17:30'
    };
    updateAttendance([record]);
  };

  const openManualPunch = (userId: string = '') => {
    const existing = userId ? getAttendanceForUser(userId, selectedDate) : null;
    setManualPunchData({
      userId,
      date: selectedDate,
      status: (existing?.status as AttendanceStatus) || 'PRESENT',
      checkIn: existing?.checkIn || '10:30',
      checkOut: existing?.checkOut || '17:30'
    });
    setShowManualPunchModal(true);
  };

  const handleManualPunchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!manualPunchData.userId) return;
    const existing = state.attendance.find(a => a.userId === manualPunchData.userId && a.date === manualPunchData.date);
    const record: Attendance = {
      id: existing?.id || Math.random().toString(36).substr(2, 9),
      userId: manualPunchData.userId,
      date: manualPunchData.date,
      status: manualPunchData.status,
      checkIn: manualPunchData.checkIn,
      checkOut: manualPunchData.checkOut
    };
    updateAttendance([record]);
    setShowManualPunchModal(false);
  };

  const filteredUsers = useMemo(() => {
    return state.users.filter(u => 
      u.name.toLowerCase().includes(searchTerm.toLowerCase()) || 
      u.email.toLowerCase().includes(searchTerm.toLowerCase()) ||
      u.position.toLowerCase().includes(searchTerm.toLowerCase())
    );
  }, [state.users, searchTerm]);

  const employeesOnly = useMemo(() => filteredUsers.filter(u => u.role !== 'ADMIN'), [filteredUsers]);

  const toggleUserSelection = (id: string) => {
    const next = new Set(selectedUserIds);
    if (next.has(id)) next.delete(id);
    else next.add(id);
    setSelectedUserIds(next);
  };

  const toggleAllSelection = () => {
    if (selectedUserIds.size === employeesOnly.length && employeesOnly.length > 0) {
      setSelectedUserIds(new Set());
    } else {
      setSelectedUserIds(new Set(employeesOnly.map(u => u.id)));
    }
  };

  const handleStaffExport = (format: 'PDF' | 'EXCEL', scope: 'SELECTED' | 'ALL') => {
    const targetIds = scope === 'SELECTED' ? Array.from(selectedUserIds) : employeesOnly.map(u => u.id);
    
    if (targetIds.length === 0) {
      alert('Please select employees to export.');
      return;
    }

    const targetUsers = state.users.filter(u => targetIds.includes(u.id));
    const filename = `KsndmcFlow_Staff_Registry_${new Date().toISOString().split('T')[0]}`;
    const headers = ['Name', 'Position', 'Type', 'Email', 'EL/AL', 'SL/ML', 'CL', 'RH', 'Used'];
    
    const rows = targetUsers.map(u => {
      const b = state.leaveBalances[u.id];
      return [
        u.name, 
        u.position, 
        u.employeeType === 'REGULAR' ? 'Insource' : 'Outsource',
        u.email,
        b?.al || 0,
        b?.ml || 0,
        b?.cl || 0,
        b?.rh || 0,
        b?.used || 0
      ];
    });

    if (format === 'EXCEL') {
      const data = targetUsers.map(u => {
        const b = state.leaveBalances[u.id];
        return {
          'Name': u.name,
          'Position': u.position,
          'Type': u.employeeType === 'REGULAR' ? 'Insource' : 'Outsource',
          'Email': u.email,
          'Earned Leave': b?.al || 0,
          'Sick Leave': b?.ml || 0,
          'Casual Leave': b?.cl || 0,
          'Restricted Holiday': b?.rh || 0,
          'Total Used': b?.used || 0
        };
      });
      exportToExcel(data, [], filename);
    } else {
      exportToPDF('Personnel Master Registry', headers, rows, [], [], filename);
    }
    setShowStaffExportMenu(false);
  };

  const handleAttendanceExport = (format: 'PDF' | 'EXCEL', scope: 'DAY' | 'WEEK' | 'MONTH' | 'YEAR') => {
    const date = new Date(selectedDate);
    let filtered: Attendance[] = [];

    if (scope === 'DAY') {
      filtered = state.attendance.filter(a => a.date === selectedDate);
    } else if (scope === 'WEEK') {
      const start = new Date(date); start.setDate(date.getDate() - date.getDay());
      const end = new Date(start); end.setDate(start.getDate() + 6);
      filtered = state.attendance.filter(a => a.date >= start.toISOString().split('T')[0] && a.date <= end.toISOString().split('T')[0]);
    } else if (scope === 'MONTH') {
      filtered = state.attendance.filter(a => a.date.startsWith(selectedDate.substring(0, 7)));
    } else {
      filtered = state.attendance.filter(a => a.date.startsWith(selectedDate.substring(0, 4)));
    }

    const filename = `Attendance_${scope}_${selectedDate}`;
    const headers = ['Date', 'Name', 'Status', 'In', 'Out'];
    const rows = filtered.map(a => {
      const user = state.users.find(u => u.id === a.userId);
      return [a.date, user?.name || 'Unknown', ATTENDANCE_LABELS[a.status], a.checkIn || '-', a.checkOut || '-'];
    });

    if (format === 'EXCEL') {
      const data = filtered.map(a => {
        const user = state.users.find(u => u.id === a.userId);
        return { Date: a.date, Name: user?.name, Status: ATTENDANCE_LABELS[a.status], In: a.checkIn, Out: a.checkOut };
      });
      exportToExcel(data, [], filename);
    } else {
      exportToPDF(`Attendance Log - ${scope}`, headers, rows, [], [], filename);
    }
    setShowAttExportMenu(false);
  };

  return (
    <div className="space-y-8 max-w-7xl mx-auto animate-fade-in-up">
      {/* Dynamic Header */}
      <div className="bg-[#0F172A] p-10 lg:p-14 rounded-[3rem] shadow-2xl relative overflow-hidden">
        <div className="absolute top-0 right-0 w-1/3 h-full bg-indigo-500/10 blur-[100px] -mr-20 -mt-20"></div>
        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-8">
          <div className="space-y-4">
            <div className="inline-flex items-center space-x-2 px-3.5 py-1.5 bg-brand-500/10 text-brand-400 rounded-full text-xs font-black uppercase tracking-widest border border-brand-500/20">
              <ShieldCheck size={14} />
              <span>HR Control Panel</span>
            </div>
            <h1 className="text-5xl lg:text-6xl font-black text-white tracking-tighter">{t.adminHeading}</h1>
            <p className="text-slate-400 font-medium text-xl max-w-xl">{t.adminSubheading}</p>
          </div>
          <div className="flex flex-wrap gap-4">
            <button onClick={() => openManualPunch()} className="flex items-center space-x-3 bg-slate-800 hover:bg-slate-700 text-white px-8 py-4 rounded-2xl font-bold transition-all border border-slate-700 shadow-xl">
              <Clock size={20} className="text-brand-400" />
              <span>{t.manualPunch}</span>
            </button>
            <button onClick={() => setShowAddUserModal(true)} className="flex items-center space-x-3 bg-brand-500 hover:bg-brand-400 text-white px-8 py-4 rounded-2xl font-bold transition-all shadow-lg shadow-brand-500/30 active:scale-95">
              <UserPlus size={20} />
              <span>{t.addStaff}</span>
            </button>
          </div>
        </div>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-6">
        <StatCard title={t.totalStaff} value={state.users.length} icon={<Users size={24} className="text-brand-600" />} color="bg-brand-50" subValue="Master Records" />
        <StatCard title={t.dailyPresence} value={state.attendance.filter(a => a.date === selectedDate && a.status === 'PRESENT').length} icon={<Check size={24} className="text-emerald-600" />} color="bg-emerald-50" trend="Active" subValue="Attendance Today" />
        <StatCard title={t.leaveRequests} value={pendingLeaves.length} icon={<Zap size={24} className="text-amber-600" />} color="bg-amber-50" urgent={pendingLeaves.length > 0} trend={pendingLeaves.length > 0 ? "Pending" : "Cleared"} subValue="HR Queue" />
        <StatCard title={GOK_HOLIDAYS_2026.length + " Holidays"} value="2026" icon={<CalendarIcon size={24} className="text-rose-600" />} color="bg-rose-50" subValue="Fiscal Calendar" />
      </div>

      {/* Tab Navigation */}
      <div className="bg-white rounded-[2.5rem] shadow-sm border border-slate-100 overflow-hidden">
        <div className="flex border-b border-slate-100 bg-slate-50/30 p-3 overflow-x-auto scrollbar-hide">
          {[
            { id: 'attendance', label: t.attendanceLogs, icon: <Clock size={18} /> },
            { id: 'employees', label: t.staffDirectory, icon: <Users size={18} /> },
            { id: 'leaves', label: t.hrApprovals, icon: <CheckCircle2 size={18} />, badge: pendingLeaves.length },
            { id: 'holidays', label: t.publicHolidays, icon: <Info size={18} /> },
            { id: 'analytics', label: t.reportsExport, icon: <Download size={18} /> }
          ].map(tab => (
            <button key={tab.id} onClick={() => setActiveTab(tab.id as any)} className={`px-6 py-4 flex items-center space-x-2.5 text-sm font-bold rounded-2xl transition-all whitespace-nowrap ${activeTab === tab.id ? 'text-brand-600 bg-white shadow-md border border-slate-100' : 'text-slate-400 hover:text-slate-900'}`}>
              {tab.icon}
              <span>{tab.label}</span>
              {tab.badge ? <span className="ml-1.5 px-2.5 py-0.5 bg-rose-500 text-white text-[10px] font-black rounded-full">{tab.badge}</span> : null}
            </button>
          ))}
        </div>

        <div className="p-8 min-h-[500px]">
          {activeTab === 'attendance' && (
            <div className="space-y-6">
              <div className="flex flex-col lg:flex-row items-center justify-between gap-4">
                <div className="flex flex-col md:flex-row items-center gap-4 w-full md:w-auto">
                   <div className="relative w-full md:w-64 group">
                    <CalendarIcon className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400 group-focus-within:text-brand-600" size={18} />
                    <input type="date" value={selectedDate} onChange={(e) => setSelectedDate(e.target.value)} className="w-full pl-12 pr-4 py-3.5 bg-slate-50 border border-slate-100 rounded-xl text-sm font-bold focus:ring-4 focus:ring-brand-600/5 focus:bg-white outline-none transition-all" />
                  </div>
                  <div className="relative">
                    <button onClick={() => setShowAttExportMenu(!showAttExportMenu)} className="flex items-center space-x-2 px-6 py-3.5 bg-slate-900 text-white rounded-xl text-xs font-bold uppercase tracking-widest hover:bg-slate-800 transition-all shadow-lg">
                      <Download size={16} />
                      <span>{t.downloadLogs}</span>
                    </button>
                    {showAttExportMenu && (
                      <div className="absolute top-full mt-3 left-0 w-72 bg-white rounded-2xl shadow-2xl border border-slate-100 z-50 p-4 animate-fade-in-up">
                        <div className="grid grid-cols-2 gap-4">
                          <div className="space-y-1">
                            <p className="text-[10px] font-black text-emerald-600 uppercase mb-2">Excel Format</p>
                            {['DAY', 'WEEK', 'MONTH', 'YEAR'].map(s => <button key={s} onClick={() => handleAttendanceExport('EXCEL', s as any)} className="w-full px-4 py-2 text-left text-xs font-bold text-slate-600 hover:bg-slate-50 rounded-lg">{s}</button>)}
                          </div>
                          <div className="space-y-1">
                            <p className="text-[10px] font-black text-rose-500 uppercase mb-2">PDF Format</p>
                            {['DAY', 'WEEK', 'MONTH', 'YEAR'].map(s => <button key={s} onClick={() => handleAttendanceExport('PDF', s as any)} className="w-full px-4 py-2 text-left text-xs font-bold text-slate-600 hover:bg-slate-50 rounded-lg">{s}</button>)}
                          </div>
                        </div>
                      </div>
                    )}
                  </div>
                </div>
                <div className="relative w-full md:w-80 group">
                   <SearchIcon className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400 group-focus-within:text-brand-600" size={18} />
                   <input type="text" placeholder={t.search} value={searchTerm} onChange={(e) => setSearchTerm(e.target.value)} className="w-full pl-12 pr-4 py-3.5 bg-slate-50 border border-slate-100 rounded-xl text-sm font-bold focus:ring-4 focus:ring-brand-600/5 focus:bg-white outline-none transition-all" />
                </div>
              </div>

              <div className="overflow-x-auto border border-slate-100 rounded-3xl shadow-sm">
                <table className="w-full text-left text-sm">
                  <thead className="bg-slate-50 text-slate-500 uppercase font-bold tracking-wider">
                    <tr>
                      <th className="px-6 py-6 font-bold">Personnel</th>
                      <th className="px-6 py-6 font-bold">Status</th>
                      <th className="px-6 py-6 font-bold">Punch In</th>
                      <th className="px-6 py-6 font-bold">Punch Out</th>
                      <th className="px-6 py-6 font-bold text-center">Actions</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-50 bg-white">
                    {employeesOnly.map(user => {
                      const record = getAttendanceForUser(user.id, selectedDate);
                      const specialDay = getSpecialDayInfo(selectedDate, user.employeeType);
                      return (
                        <tr key={user.id} className="group hover:bg-slate-50/50 transition-colors">
                          <td className="px-6 py-6 align-middle">
                            <div className="flex items-center space-x-4">
                              <div className="w-12 h-12 rounded-2xl bg-slate-100 flex items-center justify-center font-black text-sm text-slate-900 shadow-sm">
                                {user.name[0]}
                              </div>
                              <div>
                                <p className="font-bold text-slate-900 text-base">{user.name}</p>
                                <p className="text-xs text-slate-500 font-semibold uppercase tracking-wider mt-0.5">{user.position}</p>
                              </div>
                            </div>
                          </td>
                          <td className="px-6 py-6 align-middle">
                            {record ? (
                              <span className={`px-3 py-1.5 rounded-lg text-xs font-bold uppercase tracking-wider border ${STATUS_COLORS[record.status]}`}>
                                {ATTENDANCE_LABELS[record.status]}
                              </span>
                            ) : specialDay ? (
                              <span className={`px-3 py-1.5 rounded-lg text-xs font-bold uppercase tracking-wider border ${STATUS_COLORS[specialDay.type as AttendanceStatus]}`}>
                                {specialDay.name}
                              </span>
                            ) : <span className="text-slate-300 italic font-medium">No entry</span>}
                          </td>
                          <td className="px-6 py-6 align-middle">
                            <input type="time" value={record?.checkIn || '10:30'} onChange={(e) => handleAttendanceChange(user.id, record?.status || 'PRESENT', e.target.value, record?.checkOut)} className="bg-slate-50 border border-slate-100 rounded-xl px-3 py-2 text-sm font-semibold outline-none focus:bg-white focus:ring-2 focus:ring-brand-100" />
                          </td>
                          <td className="px-6 py-6 align-middle">
                            <input type="time" value={record?.checkOut || '17:30'} onChange={(e) => handleAttendanceChange(user.id, record?.status || 'PRESENT', record?.checkIn, e.target.value)} className="bg-slate-50 border border-slate-100 rounded-xl px-3 py-2 text-sm font-semibold outline-none focus:bg-white focus:ring-2 focus:ring-brand-100" />
                          </td>
                          <td className="px-6 py-6 align-middle">
                            <div className="flex justify-center space-x-2">
                              <button onClick={() => openManualPunch(user.id)} className="p-2.5 text-slate-400 hover:text-brand-600 hover:bg-brand-50 rounded-xl transition-all"><Edit3 size={16} /></button>
                              <button onClick={() => handleAttendanceChange(user.id, 'PRESENT')} className={`px-3 py-1.5 rounded-lg text-xs font-bold ${record?.status === 'PRESENT' ? 'bg-slate-900 text-white' : 'text-slate-400 hover:text-slate-900 bg-slate-100'}`}>P</button>
                              <button onClick={() => handleAttendanceChange(user.id, 'ABSENT')} className={`px-3 py-1.5 rounded-lg text-xs font-bold ${record?.status === 'ABSENT' ? 'bg-rose-500 text-white' : 'text-slate-400 hover:text-slate-900 bg-slate-100'}`}>A</button>
                            </div>
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {activeTab === 'employees' && (
            <div className="space-y-6">
              <div className="flex flex-col lg:flex-row items-center justify-between gap-6">
                <div className="space-y-1">
                  <h3 className="text-3xl font-black text-slate-900 tracking-tight">{t.staffDirectory}</h3>
                  <p className="text-xs text-slate-500 font-bold uppercase tracking-widest">Master Talent Pool & Quotas</p>
                </div>
                <div className="flex flex-wrap items-center gap-3">
                   <div className="relative">
                    <button onClick={() => setShowStaffExportMenu(!showStaffExportMenu)} className="flex items-center space-x-3 px-8 py-4 bg-brand-500 text-white rounded-2xl text-xs font-black uppercase tracking-widest hover:bg-brand-600 transition-all shadow-xl shadow-brand-500/20 group">
                      <Download size={18} className="group-hover:translate-y-0.5 transition-transform" />
                      <span>Export Registry</span>
                      <ChevronDown size={14} />
                    </button>
                    {showStaffExportMenu && (
                      <div className="absolute top-full mt-3 right-0 w-80 bg-white rounded-[2rem] shadow-2xl border border-slate-100 z-50 overflow-hidden animate-fade-in-up">
                        <div className="p-4 bg-slate-50 border-b border-slate-100 flex justify-between items-center">
                          <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Select Format & Scope</p>
                          <button onClick={() => setShowStaffExportMenu(false)} className="text-slate-300 hover:text-slate-500"><X size={16} /></button>
                        </div>
                        <div className="p-4 space-y-4">
                           <div className="space-y-2">
                             <p className="px-2 text-[9px] font-black text-emerald-600 uppercase flex items-center"><FileSpreadsheet size={14} className="mr-2" /> Excel (XLSX)</p>
                             <button onClick={() => handleStaffExport('EXCEL', 'SELECTED')} disabled={selectedUserIds.size === 0} className="w-full px-4 py-3 text-left text-xs font-bold text-slate-600 hover:bg-emerald-50 hover:text-emerald-700 rounded-xl transition-all disabled:opacity-40">Selected Personnel ({selectedUserIds.size})</button>
                             <button onClick={() => handleStaffExport('EXCEL', 'ALL')} className="w-full px-4 py-3 text-left text-xs font-bold text-slate-600 hover:bg-emerald-50 hover:text-emerald-700 rounded-xl transition-all">All Active Personnel</button>
                           </div>
                           <div className="h-px bg-slate-100"></div>
                           <div className="space-y-2">
                             <p className="px-2 text-[9px] font-black text-rose-500 uppercase flex items-center"><FileText size={14} className="mr-2" /> PDF (Document)</p>
                             <button onClick={() => handleStaffExport('PDF', 'SELECTED')} disabled={selectedUserIds.size === 0} className="w-full px-4 py-3 text-left text-xs font-bold text-slate-600 hover:bg-rose-50 hover:text-rose-700 rounded-xl transition-all disabled:opacity-40">Selected Personnel ({selectedUserIds.size})</button>
                             <button onClick={() => handleStaffExport('PDF', 'ALL')} className="w-full px-4 py-3 text-left text-xs font-bold text-slate-600 hover:bg-rose-50 hover:text-rose-700 rounded-xl transition-all">All Active Personnel</button>
                           </div>
                        </div>
                      </div>
                    )}
                  </div>
                  <div className="relative w-full lg:w-72 group">
                      <SearchIcon className="absolute left-5 top-1/2 -translate-y-1/2 text-slate-400 group-focus-within:text-brand-600" size={18} />
                      <input type="text" placeholder={t.search} value={searchTerm} onChange={(e) => setSearchTerm(e.target.value)} className="w-full pl-14 pr-6 py-4 bg-slate-50 border border-slate-100 rounded-2xl text-xs font-black focus:ring-4 focus:ring-brand-600/5 focus:bg-white outline-none transition-all" />
                   </div>
                </div>
              </div>

              <div className="overflow-x-auto border border-slate-100 rounded-[2.5rem] shadow-sm">
                <table className="w-full text-left text-sm">
                  <thead className="bg-slate-50 text-slate-500 uppercase font-bold tracking-wider">
                    <tr>
                      <th className="px-6 py-6 w-16 text-center">
                        <button onClick={toggleAllSelection} className="text-brand-500 hover:scale-110 transition-transform">
                          {selectedUserIds.size === employeesOnly.length && employeesOnly.length > 0 ? <CheckSquare size={20} /> : <Square size={20} />}
                        </button>
                      </th>
                      <th className="px-6 py-6 font-bold">Employee</th>
                      <th className="px-6 py-6 font-bold">Designation & Type</th>
                      <th className="px-6 py-6 font-bold">EL</th>
                      <th className="px-6 py-6 font-bold">SL</th>
                      <th className="px-6 py-6 font-bold">CL</th>
                      <th className="px-6 py-6 font-bold">RH</th>
                      <th className="px-6 py-6 font-bold">Used</th>
                      <th className="px-6 py-6 font-bold text-right">Edit</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-50 bg-white">
                    {employeesOnly.map(user => {
                      const balance = state.leaveBalances[user.id];
                      const isSelected = selectedUserIds.has(user.id);
                      return (
                        <tr key={user.id} className={`group hover:bg-slate-50/50 transition-all ${isSelected ? 'bg-brand-50/20' : ''}`}>
                          <td className="px-6 py-6 text-center align-middle">
                             <button onClick={() => toggleUserSelection(user.id)} className={`${isSelected ? 'text-brand-500' : 'text-slate-300 hover:text-brand-400'} transition-colors`}>
                               {isSelected ? <CheckSquare size={20} /> : <Square size={20} />}
                            </button>
                          </td>
                          <td className="px-6 py-6 align-middle">
                            <div className="flex items-center space-x-4">
                              <div className="w-12 h-12 rounded-2xl bg-slate-900 flex items-center justify-center text-white font-black text-sm shadow-lg">
                                {user.name[0]}
                              </div>
                              <div>
                                <p className="font-bold text-slate-900 text-base tracking-tight">{user.name}</p>
                                <p className="text-slate-400 font-semibold text-xs tracking-wide">{user.email}</p>
                              </div>
                            </div>
                          </td>
                          <td className="px-6 py-6 align-middle">
                             <div className="space-y-1">
                               <p className="font-bold text-slate-700 text-sm">{user.position}</p>
                               <span className={`px-2.5 py-1 rounded-full text-[10px] font-black uppercase tracking-widest border ${user.employeeType === 'REGULAR' ? 'bg-brand-50 text-brand-600 border-brand-100' : 'bg-slate-100 text-slate-400 border-slate-200'}`}>
                                 {user.employeeType === 'REGULAR' ? 'Insource' : 'Outsource'}
                               </span>
                             </div>
                          </td>
                          <td className="px-6 py-6 align-middle font-bold text-slate-900 text-base">{balance?.al || 0}</td>
                          <td className="px-6 py-6 align-middle font-bold text-slate-900 text-base">{balance?.ml || 0}</td>
                          <td className="px-6 py-6 align-middle font-bold text-slate-900 text-base">{balance?.cl || 0}</td>
                          <td className="px-6 py-6 align-middle font-bold text-slate-900 text-base">{balance?.rh || 0}</td>
                          <td className="px-6 py-6 align-middle font-black text-brand-600 text-base">{balance?.used || 0}</td>
                          <td className="px-6 py-6 align-middle text-right">
                            <button onClick={() => setEditingUser(user)} className="p-3 bg-brand-50 text-brand-600 hover:bg-brand-100 rounded-xl transition-all shadow-sm"><Pencil size={16} /></button>
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {activeTab === 'leaves' && (
            <div className="space-y-6">
              <div className="flex justify-between items-center">
                <h3 className="text-3xl font-black text-slate-900 tracking-tight">{t.hrApprovals}</h3>
              </div>
              <div className="overflow-x-auto border border-slate-100 rounded-[2.5rem] shadow-sm">
                <table className="w-full text-left text-sm">
                  <thead className="bg-slate-50 text-slate-500 uppercase font-bold tracking-wider">
                    <tr>
                      <th className="px-6 py-6 font-bold">Applicant</th>
                      <th className="px-6 py-6 font-bold">Type</th>
                      <th className="px-6 py-6 font-bold">Duration</th>
                      <th className="px-6 py-6 font-bold">Status</th>
                      <th className="px-6 py-6 font-bold text-right">Decision</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-50 bg-white">
                    {state.leaveRequests.length === 0 ? (
                      <tr><td colSpan={5} className="py-24 text-center text-slate-300 font-bold uppercase tracking-widest text-sm">HR Queue Clear</td></tr>
                    ) : (
                      state.leaveRequests.map(req => {
                        const user = state.users.find(u => u.id === req.userId);
                        return (
                          <tr key={req.id} className="group hover:bg-slate-50/50 transition-colors">
                            <td className="px-6 py-6 align-middle font-bold text-slate-900 text-base">{user?.name}</td>
                            <td className="px-6 py-6 align-middle">
                              <span className="px-3 py-1.5 bg-brand-50 text-brand-600 rounded-lg font-black text-xs uppercase tracking-wider">{req.type}</span>
                            </td>
                            <td className="px-6 py-6 align-middle text-slate-600 font-medium text-sm">{req.startDate} <span className="text-slate-400 mx-1">to</span> {req.endDate}</td>
                            <td className="px-6 py-6 align-middle">
                              {req.status === 'PENDING' ? <span className="px-3 py-1 bg-amber-50 text-amber-600 rounded-lg text-xs font-black uppercase tracking-wider">Pending</span> : req.status === 'APPROVED' ? <span className="px-3 py-1 bg-emerald-50 text-emerald-600 rounded-lg text-xs font-black uppercase tracking-wider">Approved</span> : <span className="px-3 py-1 bg-rose-50 text-rose-600 rounded-lg text-xs font-black uppercase tracking-wider">Rejected</span>}
                            </td>
                            <td className="px-6 py-6 align-middle text-right space-x-2">
                              {req.status === 'PENDING' && (
                                <>
                                  <button onClick={() => updateLeaveStatus(req.id, 'APPROVED')} className="p-3 bg-emerald-50 text-emerald-600 hover:bg-emerald-500 hover:text-white rounded-xl transition-all shadow-sm"><Check size={18} /></button>
                                  <button onClick={() => updateLeaveStatus(req.id, 'REJECTED')} className="p-3 bg-rose-50 text-rose-600 hover:bg-rose-500 hover:text-white rounded-xl transition-all shadow-sm"><X size={18} /></button>
                                </>
                              )}
                            </td>
                          </tr>
                        );
                      })
                    )}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {activeTab === 'holidays' && (
            <div className="space-y-8">
              <h3 className="text-3xl font-black text-slate-900 tracking-tight">{t.publicHolidays} (2026)</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {GOK_HOLIDAYS_2026.map(h => (
                  <div key={h.date} className="p-8 bg-white border border-slate-100 rounded-[2.5rem] flex items-center justify-between hover:shadow-xl hover:border-brand-100 transition-all group">
                    <div>
                      <p className="text-lg font-black text-slate-900 group-hover:text-brand-600 transition-colors">{h.name}</p>
                      <p className="text-xs font-bold text-slate-400 mt-1 uppercase tracking-widest">{new Date(h.date).toLocaleDateString()}</p>
                    </div>
                    <span className={`px-3 py-1.5 rounded-xl text-xs font-black uppercase tracking-widest border ${h.type === 'PUBLIC' ? 'bg-rose-50 text-rose-500 border-rose-100' : 'bg-indigo-50 text-indigo-500 border-indigo-100'}`}>{h.type}</span>
                  </div>
                ))}
              </div>
            </div>
          )}

          {activeTab === 'analytics' && (
             <div className="space-y-12">
                <div className="bg-[#0F172A] p-24 rounded-[4rem] text-center relative overflow-hidden">
                  <Download size={96} className="mx-auto text-brand-400 mb-10 animate-float" />
                  <h3 className="text-5xl font-black text-white tracking-tight mb-6">{t.reportsExport}</h3>
                  <p className="text-slate-400 font-medium text-xl max-w-2xl mx-auto mb-14">Generate secure manifests of organization health. Download encrypted reports for external audit or internal reconciliation.</p>
                  <div className="flex flex-col sm:flex-row justify-center gap-6">
                    <button onClick={() => handleStaffExport('EXCEL', 'ALL')} className="px-14 py-8 bg-emerald-500 text-white rounded-[2.5rem] font-black text-sm uppercase tracking-widest flex items-center justify-center space-x-4 hover:bg-emerald-600 shadow-2xl transition-all"><FileSpreadsheet size={24} /><span>Excel Master List</span></button>
                    <button onClick={() => handleStaffExport('PDF', 'ALL')} className="px-14 py-8 bg-white text-slate-900 rounded-[2.5rem] font-black text-sm uppercase tracking-widest flex items-center justify-center space-x-4 hover:bg-slate-50 shadow-2xl transition-all"><FileText size={24} /><span>PDF Summary</span></button>
                  </div>
                </div>
             </div>
          )}
        </div>
      </div>

      {/* Modals Placeholder */}
      {showManualPunchModal && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-6">
          <div className="absolute inset-0 bg-[#0F172A]/80 backdrop-blur-xl" onClick={() => setShowManualPunchModal(false)}></div>
          <div className="relative bg-white w-full max-w-xl rounded-[3rem] shadow-2xl p-12 overflow-hidden animate-fade-in-up">
            <h3 className="text-4xl font-black text-slate-900 mb-8 tracking-tighter">{t.manualPunch}</h3>
            <form onSubmit={handleManualPunchSubmit} className="space-y-6">
              <div className="space-y-2">
                <label className="text-xs font-black text-slate-500 uppercase tracking-wide ml-1">Target Personnel</label>
                <select required value={manualPunchData.userId} onChange={e => setManualPunchData({...manualPunchData, userId: e.target.value})} className="w-full px-6 py-4 bg-slate-50 border border-slate-100 rounded-2xl text-base font-bold focus:bg-white outline-none appearance-none">
                  <option value="">Select Employee...</option>
                  {employeesOnly.map(u => <option key={u.id} value={u.id}>{u.name}</option>)}
                </select>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                   <label className="text-xs font-black text-slate-500 uppercase tracking-wide ml-1">Date</label>
                   <input type="date" required value={manualPunchData.date} onChange={e => setManualPunchData({...manualPunchData, date: e.target.value})} className="w-full px-6 py-4 bg-slate-50 border border-slate-100 rounded-2xl text-base font-bold" />
                </div>
                <div className="space-y-2">
                   <label className="text-xs font-black text-slate-500 uppercase tracking-wide ml-1">Status</label>
                   <select value={manualPunchData.status} onChange={e => setManualPunchData({...manualPunchData, status: e.target.value as AttendanceStatus})} className="w-full px-6 py-4 bg-slate-50 border border-slate-100 rounded-2xl text-base font-bold">
                    {Object.entries(ATTENDANCE_LABELS).map(([k,v]) => <option key={k} value={k}>{v}</option>)}
                   </select>
                </div>
              </div>
              <button type="submit" className="w-full py-6 bg-slate-900 text-white rounded-[2rem] font-black text-sm uppercase tracking-[0.2em] shadow-2xl hover:bg-slate-800 transition-all">Store Transaction</button>
            </form>
          </div>
        </div>
      )}

      {showAddUserModal && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-6">
          <div className="absolute inset-0 bg-[#0F172A]/80 backdrop-blur-xl" onClick={() => setShowAddUserModal(false)}></div>
          <div className="relative bg-white w-full max-w-2xl rounded-[3rem] shadow-2xl p-12 overflow-hidden animate-fade-in-up">
            <h3 className="text-4xl font-black text-slate-900 mb-8 tracking-tighter">{t.addStaff}</h3>
            <form className="space-y-6" onSubmit={(e) => {
              e.preventDefault();
              const fd = new FormData(e.currentTarget);
              const nu: User = {
                id: Math.random().toString(36).substr(2,9),
                name: fd.get('name') as string,
                email: fd.get('email') as string,
                role: 'EMPLOYEE',
                employeeType: fd.get('type') as EmployeeType,
                position: fd.get('position') as string,
                joinDate: new Date().toISOString().split('T')[0],
                password: 'pass' + Math.floor(100+Math.random()*900)
              };
              addUser(nu, { al: Number(fd.get('al')), ml: Number(fd.get('ml')), cl: Number(fd.get('cl')), rh: Number(fd.get('rh')) });
              setShowAddUserModal(false);
            }}>
              <div className="grid grid-cols-2 gap-4">
                <input name="name" placeholder="Full Name" required className="px-6 py-4 bg-slate-50 border border-slate-100 rounded-2xl text-base font-bold outline-none" />
                <input name="email" type="email" placeholder="Work Email" required className="px-6 py-4 bg-slate-50 border border-slate-100 rounded-2xl text-base font-bold outline-none" />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <input name="position" placeholder="Designation" required className="px-6 py-4 bg-slate-50 border border-slate-100 rounded-2xl text-base font-bold outline-none" />
                <select name="type" className="px-6 py-4 bg-slate-50 border border-slate-100 rounded-2xl text-base font-bold outline-none">
                  <option value="REGULAR">Insource</option>
                  <option value="OUTSOURCED">Outsource</option>
                </select>
              </div>
              <div className="grid grid-cols-4 gap-4">
                <div className="space-y-1"><label className="text-[10px] font-black uppercase text-slate-400 ml-1">EL</label><input name="al" type="number" defaultValue={15} className="w-full px-4 py-3 bg-slate-50 border border-slate-100 rounded-xl text-sm font-black" /></div>
                <div className="space-y-1"><label className="text-[10px] font-black uppercase text-slate-400 ml-1">SL</label><input name="ml" type="number" defaultValue={10} className="w-full px-4 py-3 bg-slate-50 border border-slate-100 rounded-xl text-sm font-black" /></div>
                <div className="space-y-1"><label className="text-[10px] font-black uppercase text-slate-400 ml-1">CL</label><input name="cl" type="number" defaultValue={8} className="w-full px-4 py-3 bg-slate-50 border border-slate-100 rounded-xl text-sm font-black" /></div>
                <div className="space-y-1"><label className="text-[10px] font-black uppercase text-slate-400 ml-1">RH</label><input name="rh" type="number" defaultValue={2} className="w-full px-4 py-3 bg-slate-50 border border-slate-100 rounded-xl text-sm font-black" /></div>
              </div>
              <button type="submit" className="w-full py-6 bg-brand-500 text-white rounded-[2rem] font-black text-sm uppercase tracking-widest shadow-xl">Complete Registration</button>
            </form>
          </div>
        </div>
      )}

      {editingUser && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-6">
          <div className="absolute inset-0 bg-[#0F172A]/80 backdrop-blur-xl" onClick={() => setEditingUser(null)}></div>
          <div className="relative bg-white w-full max-w-xl rounded-[3rem] shadow-2xl p-12 overflow-hidden animate-fade-in-up">
            <h3 className="text-4xl font-black text-slate-900 mb-8 tracking-tighter">Edit Record</h3>
            <form className="space-y-6" onSubmit={(e) => {
              e.preventDefault();
              const fd = new FormData(e.currentTarget);
              updateUser(editingUser.id, {
                name: fd.get('name') as string,
                email: fd.get('email') as string,
                position: fd.get('position') as string,
                employeeType: fd.get('type') as EmployeeType,
              }, {
                al: Number(fd.get('al')), ml: Number(fd.get('ml')), cl: Number(fd.get('cl')), rh: Number(fd.get('rh'))
              });
              setEditingUser(null);
            }}>
              <input name="name" defaultValue={editingUser.name} required className="w-full px-6 py-4 bg-slate-50 border border-slate-100 rounded-2xl text-base font-bold" />
              <input name="email" defaultValue={editingUser.email} required className="w-full px-6 py-4 bg-slate-50 border border-slate-100 rounded-2xl text-base font-bold" />
              <div className="grid grid-cols-2 gap-4">
                <input name="position" defaultValue={editingUser.position} required className="px-6 py-4 bg-slate-50 border border-slate-100 rounded-2xl text-base font-bold" />
                <select name="type" defaultValue={editingUser.employeeType} className="px-6 py-4 bg-slate-50 border border-slate-100 rounded-2xl text-base font-bold">
                  <option value="REGULAR">Insource</option>
                  <option value="OUTSOURCED">Outsource</option>
                </select>
              </div>
              <div className="grid grid-cols-4 gap-4">
                 <input name="al" type="number" defaultValue={state.leaveBalances[editingUser.id]?.al} className="px-4 py-3 bg-slate-50 border border-slate-100 rounded-xl text-sm font-black" />
                 <input name="ml" type="number" defaultValue={state.leaveBalances[editingUser.id]?.ml} className="px-4 py-3 bg-slate-50 border border-slate-100 rounded-xl text-sm font-black" />
                 <input name="cl" type="number" defaultValue={state.leaveBalances[editingUser.id]?.cl} className="px-4 py-3 bg-slate-50 border border-slate-100 rounded-xl text-sm font-black" />
                 <input name="rh" type="number" defaultValue={state.leaveBalances[editingUser.id]?.rh} className="px-4 py-3 bg-slate-50 border border-slate-100 rounded-xl text-sm font-black" />
              </div>
              <button type="submit" className="w-full py-6 bg-slate-900 text-white rounded-[2rem] font-black text-sm uppercase shadow-xl">Update Master Record</button>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

export default AdminDashboard;
