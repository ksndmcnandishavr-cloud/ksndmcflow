
import React, { useState, useEffect } from 'react';
import { AppState, LeaveRequest, LeaveType, Attendance } from '../types.ts';
import { ATTENDANCE_LABELS, STATUS_COLORS, GOK_HOLIDAYS_2026, getSpecialDayInfo } from '../constants.ts';
import { getAttendanceInsights, getLeaveSummary } from '../services/geminiService.ts';
import { exportToExcel, exportToPDF } from '../services/exportService.ts';
import { 
  Calendar as CalendarIcon, 
  Sparkles, 
  AlertCircle, 
  Clock, 
  PartyPopper, 
  ArrowRight, 
  Download, 
  Info,
  History,
  CheckCircle2,
  XCircle,
  Timer,
  FileText
} from 'lucide-react';
import { translations } from '../services/translationService.ts';

interface Props {
  state: AppState;
  submitLeaveRequest: (request: Omit<LeaveRequest, 'id' | 'status' | 'appliedDate'>) => void;
}

const EmployeeDashboard: React.FC<Props> = ({ state, submitLeaveRequest }) => {
  const user = state.currentUser!;
  const balance = state.leaveBalances[user.id];
  const userAttendance = state.attendance.filter(a => a.userId === user.id).sort((a,b) => b.date.localeCompare(a.date));
  const userLeaves = state.leaveRequests.filter(r => r.userId === user.id).sort((a,b) => b.appliedDate.localeCompare(a.appliedDate));

  const t = translations[state.language];

  const [activeView, setActiveView] = useState<'attendance' | 'leaves'>('attendance');
  const [leaveForm, setLeaveForm] = useState({
    type: 'AL' as LeaveType,
    startDate: '2026-01-01',
    endDate: '2026-01-01',
    reason: ''
  });

  const [aiInsight, setAiInsight] = useState<string>(t.loading);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isExporting, setIsExporting] = useState(false);

  const checkIsBirthday = (birthDateString?: string) => {
    if (!birthDateString) return false;
    const today = new Date();
    const bday = new Date(birthDateString);
    return today.getDate() === bday.getDate() && today.getMonth() === bday.getMonth();
  };

  const isUserBirthday = checkIsBirthday(user.birthday);

  useEffect(() => {
    const fetchInsight = async () => {
      const stats = {
        present: userAttendance.filter(a => a.status === 'PRESENT').length,
        late: userAttendance.filter(a => a.status === 'LATE').length,
        absent: userAttendance.filter(a => a.status === 'ABSENT').length,
      };
      const result = await getAttendanceInsights(stats);
      setAiInsight(result);
    };
    fetchInsight();
  }, [userAttendance.length, state.language]);

  const handleApplyLeave = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!leaveForm.reason) return;
    setIsSubmitting(true);
    await getLeaveSummary(leaveForm.reason);
    submitLeaveRequest({ userId: user.id, ...leaveForm });
    setLeaveForm({ type: 'AL', startDate: '2026-01-01', endDate: '2026-01-01', reason: '' });
    setIsSubmitting(false);
    setActiveView('leaves');
  };

  const handleExport = (format: 'PDF' | 'EXCEL') => {
      setIsExporting(true);
      setTimeout(() => {
          const filename = `KsndmcFlow_MyLogs_${user.name.replace(' ', '_')}_${new Date().getTime()}`;
          const attRows = userAttendance.map(a => [
              a.date,
              user.name,
              user.employeeType,
              ATTENDANCE_LABELS[a.status],
              a.checkIn || '-',
              a.checkOut || '-'
          ]);
          const leaveRows = userLeaves.map(l => [
              user.name,
              l.type,
              l.startDate,
              l.endDate,
              l.status,
              l.reason
          ]);

          if (format === 'EXCEL') {
              const attJson = userAttendance.map(a => ({
                  Date: a.date,
                  Status: ATTENDANCE_LABELS[a.status],
                  'Punch In': a.checkIn,
                  'Punch Out': a.checkOut
              }));
              const leaveJson = userLeaves.map(l => ({
                  Type: l.type,
                  Start: l.startDate,
                  End: l.endDate,
                  Status: l.status,
                  Reason: l.reason
              }));
              exportToExcel(attJson, leaveJson, filename);
          } else {
              exportToPDF(
                  `My Attendance Log - ${user.name}`,
                  ['Date', 'Name', 'Type', 'Status', 'In', 'Out'],
                  attRows,
                  ['Name', 'Type', 'Start', 'End', 'Status', 'Reason'],
                  leaveRows,
                  filename
              );
          }
          setIsExporting(false);
      }, 800);
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 max-w-7xl mx-auto animate-fade-in-up">
      {/* Sidebar: Profile & Stats */}
      <div className="lg:col-span-4 space-y-8">
        <div className="bg-white p-8 rounded-[2rem] border border-slate-100 shadow-sm relative overflow-hidden group">
          <div className="absolute top-0 right-0 w-32 h-32 bg-brand-50 rounded-full -mr-16 -mt-16 transition-transform group-hover:scale-150 duration-700"></div>
          
          <div className="relative z-10 text-center">
            <div className="w-24 h-24 mx-auto relative mb-6">
                <div className="w-full h-full bg-slate-900 rounded-3xl flex items-center justify-center text-white text-3xl font-black shadow-lg">
                  {user.name.split(' ').map(n => n[0]).join('')}
                </div>
                {isUserBirthday && <PartyPopper className="absolute -top-3 -right-3 text-brand-500 animate-bounce" size={28} />}
            </div>
            <h2 className="text-3xl font-black text-slate-900 leading-tight tracking-tight">{user.name}</h2>
            <p className="text-xs text-slate-500 font-bold uppercase tracking-widest mt-2">{user.position}</p>
            <span className={`inline-block mt-4 text-[10px] font-black px-3 py-1 rounded-full border ${user.employeeType === 'REGULAR' ? 'bg-brand-50 text-brand-600 border-brand-100' : 'bg-slate-900 text-white uppercase'}`}>
              {user.employeeType === 'REGULAR' ? 'In-Source' : 'Outsourced'}
            </span>

            <div className="grid grid-cols-3 gap-3 mt-8">
              {[
                { label: 'EL', val: balance.al, color: 'text-brand-600', bg: 'bg-brand-50' },
                { label: 'SL', val: balance.ml, color: 'text-rose-600', bg: 'bg-rose-50' },
                { label: 'CL', val: balance.cl, color: 'text-amber-600', bg: 'bg-amber-50' },
                { label: 'RH', val: balance.rh, color: 'text-indigo-600', bg: 'bg-indigo-50' },
                { label: 'CO', val: balance.comoff, color: 'text-emerald-600', bg: 'bg-emerald-50' },
                { label: 'Used', val: balance.used, color: 'text-slate-500', bg: 'bg-slate-50' }
              ].map(stat => (
                <div key={stat.label} className={`${stat.bg} p-4 rounded-2xl border border-white flex flex-col items-center justify-center transition-transform hover:scale-105 shadow-sm`}>
                  <p className="text-[9px] font-bold uppercase tracking-tighter opacity-60 mb-0.5">{stat.label}</p>
                  <p className={`text-base font-black ${stat.color}`}>{stat.val}</p>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* AI Insight Card */}
        <div className="bg-[#0F172A] rounded-[2rem] p-8 text-white relative overflow-hidden group shadow-xl">
          <div className="flex items-center space-x-2 mb-4">
            <Sparkles size={18} className="text-brand-400 animate-pulse" />
            <span className="text-[10px] font-black uppercase tracking-[0.2em] text-brand-400">{t.aiInsight}</span>
          </div>
          <p className="text-lg font-medium leading-relaxed text-slate-100 italic">{aiInsight}</p>
        </div>

        {/* Upcoming Holidays */}
        <div className="bg-white rounded-[2rem] border border-slate-100 p-6 shadow-sm">
          <h3 className="font-black text-slate-900 text-sm tracking-tight flex items-center space-x-2 mb-4 px-2">
            <Info size={18} className="text-brand-500" />
            <span>{t.publicHolidays}</span>
          </h3>
          <div className="space-y-3 max-h-[260px] overflow-y-auto pr-1 scrollbar-hide px-2">
            {GOK_HOLIDAYS_2026.slice(0, 5).map(h => (
              <div key={h.date} className="flex items-center justify-between p-4 bg-slate-50 rounded-2xl hover:bg-white hover:shadow-sm border border-transparent hover:border-slate-100 transition-all">
                <div>
                  <p className="text-xs font-black text-slate-900 truncate max-w-[140px]">{h.name}</p>
                  <p className="text-[10px] font-bold text-slate-400 mt-0.5">{new Date(h.date).toLocaleDateString(state.language === 'EN' ? 'en-IN' : 'kn-IN', { day: 'numeric', month: 'short' })}</p>
                </div>
                <span className={`px-2.5 py-1 rounded-lg text-[9px] font-black uppercase ${h.type === 'PUBLIC' ? 'bg-rose-50 text-rose-500' : 'bg-indigo-50 text-indigo-500'}`}>
                  {h.type}
                </span>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Main Content: Apply Leave & Logs */}
      <div className="lg:col-span-8 space-y-8">
        <div className="bg-white rounded-[2rem] border border-slate-100 p-8 shadow-sm">
          <h3 className="text-3xl font-black text-slate-900 tracking-tight mb-8 flex items-center space-x-3">
            <CalendarIcon size={28} className="text-brand-600" />
            <span>{t.applyLeave}</span>
          </h3>
          <form onSubmit={handleApplyLeave} className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="space-y-2">
                <label className="text-xs font-bold text-slate-400 uppercase tracking-widest ml-1">{t.leaveType}</label>
                <select 
                  value={leaveForm.type} 
                  onChange={e => setLeaveForm(prev => ({ ...prev, type: e.target.value as LeaveType }))}
                  className="w-full bg-slate-50 border border-slate-100 rounded-xl px-4 py-4 text-base font-bold outline-none focus:bg-white focus:ring-4 focus:ring-brand-500/5 transition-all appearance-none cursor-pointer"
                >
                  <option value="AL">{t.earned} (EL)</option>
                  <option value="ML">{t.sick} (SL)</option>
                  <option value="CL">{t.casual} (CL)</option>
                  <option value="RH">{t.restricted} (RH)</option>
                  <option value="COMOFF">Comp Off (COMOFF)</option>
                </select>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <label className="text-xs font-bold text-slate-400 uppercase tracking-widest ml-1">{t.fromDate}</label>
                  <input type="date" value={leaveForm.startDate} onChange={e => setLeaveForm(prev => ({ ...prev, startDate: e.target.value }))} className="w-full bg-slate-50 border border-slate-100 rounded-xl px-4 py-4 text-sm font-bold outline-none focus:bg-white transition-all" />
                </div>
                <div className="space-y-2">
                  <label className="text-xs font-bold text-slate-400 uppercase tracking-widest ml-1">{t.toDate}</label>
                  <input type="date" value={leaveForm.endDate} onChange={e => setLeaveForm(prev => ({ ...prev, endDate: e.target.value }))} className="w-full bg-slate-50 border border-slate-100 rounded-xl px-4 py-4 text-sm font-bold outline-none focus:bg-white transition-all" />
                </div>
              </div>
            </div>
            <div className="space-y-2">
              <label className="text-xs font-bold text-slate-400 uppercase tracking-widest ml-1">{t.reason}</label>
              <textarea 
                rows={3} 
                value={leaveForm.reason} 
                onChange={e => setLeaveForm(prev => ({ ...prev, reason: e.target.value }))}
                className="w-full bg-slate-50 border border-slate-100 rounded-xl px-5 py-4 text-base font-medium outline-none focus:bg-white focus:ring-4 focus:ring-brand-500/5 transition-all resize-none"
                placeholder="Briefly explain the reason for leave..."
              ></textarea>
            </div>
            <button 
              type="submit" 
              disabled={isSubmitting || !leaveForm.reason} 
              className="w-full py-5 bg-slate-900 text-white rounded-xl font-black text-sm uppercase tracking-widest flex items-center justify-center space-x-3 hover:bg-slate-800 transition-all disabled:opacity-50"
            >
              {isSubmitting ? <div className="w-5 h-5 border-2 border-white/20 border-t-white rounded-full animate-spin"></div> : <><span>{t.submitApplication}</span><ArrowRight size={18} /></>}
            </button>
          </form>
        </div>

        <div className="bg-white rounded-[2rem] border border-slate-100 overflow-hidden shadow-sm">
          <div className="p-5 border-b border-slate-50 flex justify-between items-center bg-slate-50/20">
            <div className="flex bg-white p-1.5 rounded-2xl border border-slate-100">
              <button 
                onClick={() => setActiveView('attendance')}
                className={`flex items-center space-x-2 px-5 py-2.5 rounded-xl text-xs font-black uppercase tracking-widest transition-all ${activeView === 'attendance' ? 'bg-slate-900 text-white' : 'text-slate-400 hover:text-slate-600'}`}
              >
                <Clock size={16} />
                <span>Attendance</span>
              </button>
              <button 
                onClick={() => setActiveView('leaves')}
                className={`flex items-center space-x-2 px-5 py-2.5 rounded-xl text-xs font-black uppercase tracking-widest transition-all ${activeView === 'leaves' ? 'bg-slate-900 text-white' : 'text-slate-400 hover:text-slate-600'}`}
              >
                <History size={16} />
                <span>Leave Status</span>
              </button>
            </div>
            <button 
                onClick={() => handleExport('EXCEL')}
                className="p-3 bg-white text-slate-400 border border-slate-100 rounded-xl hover:text-brand-600 hover:border-brand-100 transition-all"
                title="Download History"
            >
                <Download size={18} />
            </button>
          </div>

          <div className="min-h-[400px]">
            {activeView === 'attendance' ? (
              <div className="divide-y divide-slate-50 max-h-[500px] overflow-y-auto scrollbar-hide">
                {userAttendance.length === 0 ? (
                  <div className="p-16 text-center">
                    <AlertCircle className="mx-auto text-slate-200 mb-3" size={40} />
                    <p className="text-xs font-bold text-slate-300 uppercase tracking-widest">No activity recorded yet</p>
                  </div>
                ) : (
                  userAttendance.map(a => (
                    <div key={a.id} className="p-6 flex justify-between items-center hover:bg-slate-50 transition-colors">
                      <div>
                        <p className="text-base font-bold text-slate-900">
                          {new Date(a.date).toLocaleDateString(state.language === 'EN' ? 'en-IN' : 'kn-IN', { day: 'numeric', month: 'short', year: 'numeric' })}
                        </p>
                        <p className="text-xs font-bold text-slate-400 uppercase tracking-widest mt-1">
                          {a.checkIn ? `${a.checkIn} — ${a.checkOut || 'In Progress'}` : 'Absence/Leave'}
                        </p>
                      </div>
                      <span className={`px-3 py-1.5 rounded-lg text-[10px] font-black uppercase tracking-widest border ${STATUS_COLORS[a.status]}`}>
                        {ATTENDANCE_LABELS[a.status]}
                      </span>
                    </div>
                  ))
                )}
              </div>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full text-left text-sm">
                  <thead className="bg-slate-50 text-slate-500 uppercase font-bold tracking-wider">
                    <tr>
                      <th className="px-6 py-5 font-bold">Dates</th>
                      <th className="px-6 py-5 font-bold">Type</th>
                      <th className="px-6 py-5 font-bold">Reason</th>
                      <th className="px-6 py-5 font-bold text-center">Status</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-50">
                    {userLeaves.length === 0 ? (
                      <tr>
                        <td colSpan={4} className="p-16 text-center">
                          <History className="mx-auto text-slate-200 mb-3" size={40} />
                          <p className="text-xs font-bold text-slate-300 uppercase tracking-widest">No leave history found</p>
                        </td>
                      </tr>
                    ) : (
                      userLeaves.map(l => (
                        <tr key={l.id} className="group hover:bg-slate-50 transition-colors">
                          <td className="px-6 py-6 align-middle">
                            <div className="space-y-0.5">
                              <p className="font-bold text-slate-900 text-sm">{l.startDate}</p>
                              <p className="text-xs text-slate-400 font-medium">to {l.endDate}</p>
                            </div>
                          </td>
                          <td className="px-6 py-6 align-middle">
                            <span className="px-2.5 py-1 bg-brand-50 text-brand-600 rounded-lg font-black text-[10px] uppercase tracking-widest">
                              {l.type}
                            </span>
                          </td>
                          <td className="px-6 py-6 align-middle">
                            <p className="text-slate-600 font-medium text-sm italic max-w-xs truncate" title={l.reason}>
                              "{l.reason}"
                            </p>
                          </td>
                          <td className="px-6 py-6 align-middle">
                            <div className="flex justify-center">
                              {l.status === 'PENDING' ? (
                                <span className="flex items-center space-x-1.5 px-3 py-1 bg-amber-50 text-amber-600 border border-amber-100 rounded-lg text-[10px] font-black uppercase tracking-widest">
                                  <Timer size={12} />
                                  <span>Pending</span>
                                </span>
                              ) : l.status === 'APPROVED' ? (
                                <span className="flex items-center space-x-1.5 px-3 py-1 bg-emerald-50 text-emerald-600 border border-emerald-100 rounded-lg text-[10px] font-black uppercase tracking-widest">
                                  <CheckCircle2 size={12} />
                                  <span>Approved</span>
                                </span>
                              ) : (
                                <span className="flex items-center space-x-1.5 px-3 py-1 bg-rose-50 text-rose-600 border border-rose-100 rounded-lg text-[10px] font-black uppercase tracking-widest">
                                  <XCircle size={12} />
                                  <span>Rejected</span>
                                </span>
                              )}
                            </div>
                          </td>
                        </tr>
                      ))
                    )}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default EmployeeDashboard;
