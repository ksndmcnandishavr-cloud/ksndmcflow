import { GoogleGenAI } from "@google/genai";

/**
 * Summarizes an employee's leave request reason professionally using Gemini.
 * @param reason The raw reason text from the leave request.
 * @returns A concise, professional summary.
 */
export async function getLeaveSummary(reason: string): Promise<string> {
  // Initialize GoogleGenAI inside the function to ensure the latest API key is used
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: `Summarize this employee leave request reason professionally in one short sentence: "${reason}"`,
      config: {
        // Temperature 0.5 for consistent professional summaries
        temperature: 0.5,
        // For Gemini 3 models, if we were setting maxOutputTokens we should also consider thinkingBudget.
        // For this simple text task, we let the model decide its reasoning path.
      }
    });
    return response.text?.trim() || "No summary available.";
  } catch (error) {
    console.error("Gemini Error:", error);
    return "Error generating summary.";
  }
}

/**
 * Analyzes monthly attendance statistics and provides an encouraging insight.
 * @param stats Object containing counts for present, late, and absent days.
 * @returns A personalized insight string.
 */
export async function getAttendanceInsights(stats: { present: number, late: number, absent: number }): Promise<string> {
  // Initialize GoogleGenAI inside the function to ensure the latest API key is used
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: `Analyze these monthly attendance stats for an employee: Present: ${stats.present}, Late: ${stats.late}, Absent: ${stats.absent}. Provide a short encouraging sentence.`,
      config: {
        temperature: 0.7,
      }
    });
    return response.text?.trim() || "Keep up the good work!";
  } catch (error) {
    console.error("Gemini Error:", error);
    return "Great job maintaining your schedule!";
  }
}