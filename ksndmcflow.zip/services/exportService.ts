
import { jsPDF } from 'jspdf';
import 'jspdf-autotable';
import * as XLSX from 'xlsx';

export const exportToExcel = (
  attendanceData: any[],
  leaveData: any[],
  filename: string
) => {
  const wb = XLSX.utils.book_new();
  
  if (attendanceData && attendanceData.length > 0) {
    const wsAttendance = XLSX.utils.json_to_sheet(attendanceData);
    XLSX.utils.book_append_sheet(wb, wsAttendance, "Attendance");
  }
  
  if (leaveData && leaveData.length > 0) {
    const wsLeaves = XLSX.utils.json_to_sheet(leaveData);
    XLSX.utils.book_append_sheet(wb, wsLeaves, "Leave Requests");
  }

  // Handle case where both are empty
  if (!wb.SheetNames.length) {
    const wsEmpty = XLSX.utils.json_to_sheet([{ Message: "No data available for the selected period" }]);
    XLSX.utils.book_append_sheet(wb, wsEmpty, "Empty");
  }

  XLSX.writeFile(wb, `${filename}.xlsx`);
};

export const exportToPDF = (
  title: string,
  attendanceHeaders: string[],
  attendanceRows: any[][],
  leaveHeaders: string[],
  leaveRows: any[][],
  filename: string
) => {
  const doc = new jsPDF('l', 'mm', 'a4');
  const timestamp = new Date().toLocaleString();

  // Branded Header
  doc.setFontSize(22);
  doc.setTextColor(79, 110, 242); // brand-500
  doc.setFont('helvetica', 'bold');
  doc.text('KsndmcFlow', 14, 20);
  
  doc.setFontSize(14);
  doc.setTextColor(15, 23, 42); // slate-900
  doc.text(title, 14, 30);
  
  doc.setFontSize(9);
  doc.setTextColor(148, 163, 184); // slate-400
  doc.text(`Generated: ${timestamp} | Secure Node Export`, 14, 35);

  let currentY = 45;

  // Attendance Table
  if (attendanceRows && attendanceRows.length > 0) {
    doc.setFontSize(12);
    doc.setTextColor(15, 23, 42);
    doc.text('Attendance Ledger', 14, currentY);
    
    (doc as any).autoTable({
      startY: currentY + 5,
      head: [attendanceHeaders],
      body: attendanceRows,
      theme: 'grid',
      headStyles: { fillColor: [79, 110, 242], textColor: [255, 255, 255], fontStyle: 'bold' },
      styles: { fontSize: 8, cellPadding: 3 },
      alternateRowStyles: { fillColor: [248, 250, 252] },
    });
    
    if ((doc as any).lastAutoTable) {
        currentY = (doc as any).lastAutoTable.finalY + 15;
    } else {
        currentY += 20;
    }
  }

  // Leave Table
  if (leaveRows && leaveRows.length > 0) {
    if (currentY > 170) { 
        doc.addPage(); 
        currentY = 20; 
    }
    
    doc.setFontSize(12);
    doc.setTextColor(15, 23, 42);
    doc.text('Leave Status Summary', 14, currentY);
    
    (doc as any).autoTable({
      startY: currentY + 5,
      head: [leaveHeaders],
      body: leaveRows,
      theme: 'grid',
      headStyles: { fillColor: [15, 23, 42], textColor: [255, 255, 255], fontStyle: 'bold' },
      styles: { fontSize: 8, cellPadding: 3 },
      alternateRowStyles: { fillColor: [248, 250, 252] },
    });
  }

  doc.save(`${filename}.pdf`);
};
