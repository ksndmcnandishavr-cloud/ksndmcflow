
import { initializeApp } from "firebase/app";
import { getAnalytics, isSupported } from "firebase/analytics";
import { getDatabase } from "firebase/database";

// Your web app's Firebase configuration
const firebaseConfig = {
  apiKey: "AIzaSyBGd-_E0ppesU4VytWWZcxpW5mMV1ufsUA",
  authDomain: "ksndmcflow.firebaseapp.com",
  databaseURL: "https://ksndmcflow-default-rtdb.firebaseio.com",
  projectId: "ksndmcflow",
  storageBucket: "ksndmcflow.firebasestorage.app",
  messagingSenderId: "603023255264",
  appId: "1:603023255264:web:93e6ae6ba12f19cd251285",
  measurementId: "G-PVG22V7EQF"
};

// Initialize Firebase App
const app = initializeApp(firebaseConfig);

// Initialize Realtime Database
// This is required for the current App.tsx implementation.
export const db = getDatabase(app);

// Initialize Analytics conditionally
export const initAnalytics = async () => {
  try {
    const supported = await isSupported();
    if (supported) {
      return getAnalytics(app);
    }
  } catch (err) {
    console.warn("Firebase Analytics not supported in this environment:", err);
  }
  return null;
};

// Start initialization
initAnalytics();

export { app };
